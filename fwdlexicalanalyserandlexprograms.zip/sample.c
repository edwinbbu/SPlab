#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
int main()
{
    int num1,num2,num3;
    num1=50;
    num2=40;
    num3=num1+num2;
    printf("%d result:",num3);
    <=
    >=
    !=
     >
     <
    return 0;
}   
