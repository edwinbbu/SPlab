#include<stdio.h>
main()
{
	int a=6,b;
	float sum;
	char x;
	printf("enter number");
	scanf("%d",&b);
	sum=a+b;
}
